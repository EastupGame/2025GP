﻿#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<conio.h>
#include"screen.h"
#include"game.h"
#include"Scenes.h"
PLAYER g_sPlayer;
FOOD g_sFood;
DEER g_sDeer[3];
GAME_MANAGER g_Manager;
void Init()
{
	{
		g_sPlayer.string = "┌─◐─┘";
		g_sPlayer.nCenterX = 2;	g_sPlayer.nCenterY = 0;
		g_sPlayer.nMoveX = 22;	g_sPlayer.nMoveY = 22;
		updatePlayer(&g_sPlayer);

		initFoodX(&g_sFood, &g_sPlayer);
		g_sFood.nMoveY = g_sPlayer.nMoveY - 1;
		g_sFood.string = "♥";
		g_sFood.oldTime = clock();
		g_sFood.nIsReady = 0;	//준비상태
		g_sFood.moveTime = 100;

		g_sDeer[0].string = "(´･ω･)";
		g_sDeer[0].nMoveX = 20;	g_sDeer[0].nMoveY = 2;
		g_sDeer[0].oldTime = clock();
		g_sDeer[0].moveTime = 100;
		g_sDeer[0].nDist = 1;

		g_sDeer[1].string = "∧∞∧";
		g_sDeer[1].nMoveX = 30;	g_sDeer[1].nMoveY = 3;
		g_sDeer[1].oldTime = clock();
		g_sDeer[1].moveTime = 200;
		g_sDeer[1].nDist = 1;

		g_sDeer[2].string = "ヽ(・ω・)ノ ";
		g_sDeer[2].nMoveX = 10;	g_sDeer[2].nMoveY = 4;
		g_sDeer[2].oldTime = clock();
		g_sDeer[2].moveTime = 50;
		g_sDeer[2].nDist = 1;
	}

	g_Manager.sState = INIT;
	
}
void Update()
{
	clock_t gameCurTime = clock();
	switch (g_Manager.sState)
	{
	case INIT:
	{
		{
			int nKey;
			if (_kbhit())
			{
				nKey = _getch();
				switch (nKey)
				{
				case ' ':
					g_Manager.sState = READY;
					g_Manager.oldTime = clock();
					break;
				}
			}
		}
	}
		break;
	case READY:
		if (gameCurTime - g_Manager.oldTime > 3000)
		{
			g_Manager.oldTime = gameCurTime;
			g_Manager.sState = RUNNING;
		}
		break;
	case RUNNING:
	{
		//키 처리
		{
			int nKey;
			if (_kbhit())
			{
				nKey = _getch();
				switch (nKey)
				{
				case 'j':
					g_sPlayer.nMoveX--;
					updatePlayer(&g_sPlayer);
					break;
				case 'l':
					g_sPlayer.nMoveX++;
					updatePlayer(&g_sPlayer);
					break;
				case 'k':
					if (g_sFood.nIsReady == 0)
					{
						g_sFood.nIsReady = 1;
						g_sFood.oldTime = clock();
						initFoodX(&g_sFood, &g_sPlayer);
						g_sFood.nMoveY = g_sPlayer.nMoveY - 1;
					}
					break;
				}
			}
		}

		//시간 간격에 의한 음식 이동(발사)
		{
			g_sFood.curTime = clock();
			if (g_sFood.nIsReady == 1)	//음식이 이동 중이면
			{
				if (g_sFood.curTime - g_sFood.oldTime > g_sFood.moveTime)
				{
					if (g_sFood.nMoveY > 1)
					{
						g_sFood.nMoveY--;
						g_sFood.oldTime = g_sFood.curTime;
					}
					else   // 초기화
					{
						g_sFood.nIsReady = 0;			//준비상태
						initFoodX(&g_sFood, &g_sPlayer);
						g_sFood.nMoveY = g_sPlayer.nMoveY - 1;
					}
				}
			}
			else
			{
				initFoodX(&g_sFood, &g_sPlayer);
			}
		}

		//사슴 이동 처리
		{
			for (int i = 0; i < 3; i++)
			{
				g_sDeer[i].curTime = clock();
				if (g_sDeer[i].curTime - g_sDeer[i].oldTime > g_sDeer[i].moveTime)
				{
					g_sDeer[i].oldTime = g_sDeer[i].curTime;
					if (g_sDeer[i].nMoveX + g_sDeer[i].nDist > 0 &&
						g_sDeer[i].nMoveX + 10 + g_sDeer[i].nDist < 48)
					{
						g_sDeer[i].nMoveX += g_sDeer[i].nDist;
					}
					else
					{
						g_sDeer[i].nDist = g_sDeer[i].nDist * -1;
					}

				}
			}

		}
	}
	
		break;
	}

}
void Render()
{
	
	ScreenClear();
	switch (g_Manager.sState)
	{
	case INIT:
		InitScreen();
		break;
	case READY:
		ReadyScreen();
		break;
	case RUNNING:
		RunningScreen(&g_sPlayer, &g_sFood, g_sDeer);
		break;
	}
	ScreenFlipping();
}
void Release() {}

void main()
{
	ScreenInit();
	Init();
	while (1)
	{
		Update();
		Render();
	}
	Release();
	ScreenRelease();
}