#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<conio.h>
#include"screen.h"
#include"game.h"
#include"Scenes.h"
typedef enum _SCENE_STATE{INIT, READY, RUNNING, SUCCESS,
FAILED, STOP, RESULT}SCENE_STATE;
typedef struct _GAME_MANAGER
{
	SCENE_STATE sState;
	char string[100];
	clock_t oldTime;

}GAME_MANAGER;
void InitScreen();
void RunningScreen(PLAYER* p, FOOD* f, DEER arr[]);
void ReadyScreen();
void HitMessage(int nX, int nY);


