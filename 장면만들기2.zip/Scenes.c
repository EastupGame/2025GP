﻿#include "Scenes.h"
#include "game.h"
void InitScreen()
{
	ScreenPrint(0, 0, "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
	ScreenPrint(0, 1, "┃                                          ┃");
	ScreenPrint(0, 2, "┃                                          ┃");
	ScreenPrint(0, 3, "┃                                          ┃");
	ScreenPrint(0, 4, "┃            하트 던지기 게임              ┃");
	ScreenPrint(0, 5, "┃                                          ┃");
	ScreenPrint(0, 6, "┃     (*✪ω✪)                               ┃");
	ScreenPrint(0, 7, "┃        ♡                                 ┃");
	ScreenPrint(0, 8, "┃         ♡                                ┃");
	ScreenPrint(0, 9, "┃         ♡                                ┃");
	ScreenPrint(0, 10, "┃         ♡                                ┃");
	ScreenPrint(0, 11, "┃                                          ┃");
	ScreenPrint(0, 12, "┃                                          ┃");
	ScreenPrint(0, 13, "┃                                          ┃");
	ScreenPrint(0, 14, "┃      ♡♡  ♡♡                              ┃");
	ScreenPrint(0, 15, "┃       ♡♡♡♡♡♡♡                            ┃");
	ScreenPrint(0, 16, "┃        ♡♡♡♡♡♡                            ┃");
	ScreenPrint(0, 17, "┃         ♡♡♡♡♡                            ┃");
	ScreenPrint(0, 18, "┃          ♡♡♡    space 를 눌러 주세요     ┃");
	ScreenPrint(0, 19, "┃              ♡                           ┃");
	ScreenPrint(0, 20, "┃          ┌─○─┘                           ┃");
	ScreenPrint(0, 21, "┃                                          ┃");
	ScreenPrint(0, 22, "┃                                          ┃");
	ScreenPrint(0, 23, "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
}
void RunningScreen(PLAYER* p, FOOD* f, DEER arr[])
{
	char string[100];
	ScreenPrint(0, 1, "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
	ScreenPrint(0, 2, "┃                                          ┃");
	ScreenPrint(0, 3, "┃                                          ┃");
	ScreenPrint(0, 4, "┃                                          ┃");
	ScreenPrint(0, 5, "┃                                          ┃");
	ScreenPrint(0, 6, "┃                                          ┃");
	ScreenPrint(0, 7, "┃                                          ┃");
	ScreenPrint(0, 8, "┃                                          ┃");
	ScreenPrint(0, 9, "┃                                          ┃");
	ScreenPrint(0, 10, "┃                                          ┃");
	ScreenPrint(0, 11, "┃                                          ┃");
	ScreenPrint(0, 12, "┃                                          ┃");
	ScreenPrint(0, 13, "┃                                          ┃");
	ScreenPrint(0, 14, "┃                                          ┃");
	ScreenPrint(0, 15, "┃                                          ┃");
	ScreenPrint(0, 16, "┃                                          ┃");
	ScreenPrint(0, 17, "┃                                          ┃");
	ScreenPrint(0, 18, "┃                                          ┃");
	ScreenPrint(0, 19, "┃                                          ┃");
	ScreenPrint(0, 20, "┃                                          ┃");
	ScreenPrint(0, 21, "┃                                          ┃");
	ScreenPrint(0, 22, "┃                                          ┃");
	ScreenPrint(0, 23, "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");

	sprintf(string, "주인공 이동좌표 : %d, %d", p->nMoveX, p->nMoveY);
	ScreenPrint(0, 0, string);
	ScreenPrint(p->nX, p->nY, p->string);
	ScreenPrint(f->nMoveX, f->nMoveY, f->string);
	for (int i = 0; i < 3; i++)
	{
		ScreenPrint(arr[i].nMoveX, arr[i].nMoveY, arr[i].string);
	}

}
void ReadyScreen()
{
	ScreenPrint(0, 0, "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
	ScreenPrint(0, 1, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 2, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 3, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 4, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 5, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 6, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 7, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 8, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 9, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 10, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡              ♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 11, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡    READY!    ♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 12, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡              ♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 13, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 14, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 15, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 16, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 17, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 18, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 19, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 20, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 21, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 22, "┃♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡♡┃");
	ScreenPrint(0, 23, "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
}

