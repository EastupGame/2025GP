#include "game.h"

void updatePlayer(PLAYER* p)
{
	p->nX = p->nMoveX - p->nCenterX;
	p->nY = p->nMoveY;
}
