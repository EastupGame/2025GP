#pragma once
#include<time.h>
typedef struct _PLAYER
{
	int nCenterX, nCenterY;	//�߽���ǥ
	int nMoveX, nMoveY;		//�̵���ǥ
	int nX, nY;				//�����ǥ
	char* string;
}PLAYER;

typedef struct _FOOD
{
	char* string;
	int nMoveX, nMoveY;
	clock_t oldTime, curTime;
	clock_t moveTime;
	int nIsReady;	// 0 : �غ�, 1 : �߻�
}FOOD;

typedef struct _DEER
{
	char* string;
	int nMoveX, nMoveY;		//�̵� ��ǥ
	clock_t oldTime, curTime;
	clock_t moveTime;
	int nDist;				//�̵� �Ÿ�
}DEER;
void updatePlayer(PLAYER* p);
void initFoodX(FOOD* f, PLAYER* p);