#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<conio.h>
#include"screen.h"
#include"game.h"

PLAYER g_sPlayer;
FOOD g_sFood;
void Init()
{
	g_sPlayer.string = "���ΰ�";
	g_sPlayer.nCenterX = 2;	g_sPlayer.nCenterY = 0;
	g_sPlayer.nMoveX = 34;	g_sPlayer.nMoveY = 18;
	updatePlayer(&g_sPlayer);

	g_sFood.nX = g_sPlayer.nMoveX;
	g_sFood.nY = g_sPlayer.nMoveY - 1;
	g_sFood.string = "��";
	g_sFood.oldTime = clock();
	g_sFood.nIsReady = 0;	//�غ����
	g_sFood.moveTime = 200;

}
void Update()
{
	int nKey;
	//Ű ó��
	{
		if (_kbhit())
		{
			nKey = _getch();
			switch (nKey)
			{
			case 'j':
				g_sPlayer.nMoveX--;
				updatePlayer(&g_sPlayer);
				break;
			case 'l':
				g_sPlayer.nMoveX++;
				updatePlayer(&g_sPlayer);
				break;
			case 'k':
				if (g_sFood.nIsReady == 0)
				{
					g_sFood.nIsReady = 1;
					g_sFood.oldTime = clock();
					g_sFood.nX = g_sPlayer.nMoveX;
					g_sFood.nY = g_sPlayer.nMoveY - 1;
				}
				break;
			}
		}
	}


	//�ð� ���ݿ� ���� �̵�
	g_sFood.curTime = clock();
	if(g_sFood.nIsReady == 1)	//������ �̵� ���̸�
	{
		if (g_sFood.curTime - g_sFood.oldTime > g_sFood.moveTime)
		{
			if (g_sFood.nY > 0)
			{
				g_sFood.nY--;
				g_sFood.oldTime = g_sFood.curTime;
			}
			else   // �ʱ�ȭ
			{
				g_sFood.nIsReady = 0;			//�غ����
				g_sFood.nX = g_sPlayer.nMoveX;
				g_sFood.nY = g_sPlayer.nMoveY - 1;
			}
		}
	}
	else
	{
		g_sFood.nX = g_sPlayer.nMoveX;
	}


}
void Render()
{
	char string[100];
	ScreenClear();
	sprintf(string, "���ΰ� �̵���ǥ : %d, %d", g_sPlayer.nMoveX, g_sPlayer.nMoveY);
	ScreenPrint(0, 0, string);
	ScreenPrint(g_sPlayer.nX, g_sPlayer.nY, g_sPlayer.string);
	ScreenPrint(g_sFood.nX, g_sFood.nY, g_sFood.string);
	ScreenFlipping();
}
void Release() {}

void main()
{
	ScreenInit();
	Init();
	while (1)
	{
		Update();
		Render();
	}
	Release();
	ScreenRelease();
}