#include<stdio.h>
#include"screen.h"
char* string = "���ΰ�";
void Init(){}
void Update(){}
void Render()
{
	ScreenClear();
	ScreenPrint(20, 15, string);
	ScreenFlipping();
}
void Release(){}

void main()
{
	ScreenInit();
	Init();
	while (1)
	{
		Update();
		Render();
	}
	Release();
	ScreenRelease();
}