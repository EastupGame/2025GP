#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
#include<conio.h>
#include"screen.h"

typedef struct _PLAYER
{
	int nCenterX, nCenterY;		//�߽� ��ǥ
	int nMoveX, nMoveY;			//�̵� ��ǥ
	int nX, nY;					//��� ��ǥ
	char* string;
} PLAYER;
PLAYER g_sPlayer;

void Init() 
{
	g_sPlayer.string = "���ΰ�";
	g_sPlayer.nCenterX = 2;
	g_sPlayer.nCenterY = 0;
	g_sPlayer.nMoveX = 76;
	g_sPlayer.nMoveY = 22;
	g_sPlayer.nX = g_sPlayer.nMoveX - g_sPlayer.nCenterX;
	g_sPlayer.nY = g_sPlayer.nMoveY;
}
void Update() 
{
	int nKey;
	//*********************************
	//Ű ó��
	//*********************************a
	if (_kbhit())
	{
		nKey = _getch();
		switch (nKey)
		{
		case 'j':
			g_sPlayer.nMoveX--;
			g_sPlayer.nX = g_sPlayer.nMoveX - g_sPlayer.nCenterX;
			g_sPlayer.nY = g_sPlayer.nMoveY;
			break;
		case 'k':
			g_sPlayer.nMoveX++;
			g_sPlayer.nX = g_sPlayer.nMoveX - g_sPlayer.nCenterX;
			g_sPlayer.nY = g_sPlayer.nMoveY;
			break;
		default:
			break;
		}
	}
}
void Render()
{
	char string[100] = { 0, };
	ScreenClear();
	//
	sprintf(string, "���ΰ� �̵� ��ǥ : %d, %d", g_sPlayer.nMoveX, g_sPlayer.nMoveY);
	ScreenPrint(0, 0, string);
	ScreenPrint(g_sPlayer.nX, g_sPlayer.nY, g_sPlayer.string);
	ScreenFlipping();
}
void Release() {}

void main()
{
	ScreenInit();
	Init();
	while (1)
	{
		Update();
		Render();
	}
	Release();
	ScreenRelease();
}