#include "game.h"

void updatePlayer(PLAYER* p)
{
	p->nX = p->nMoveX - p->nCenterX;
	p->nY = p->nMoveY;
}

void initFoodX(FOOD* f, PLAYER* p)
{
	f->nMoveX = p->nMoveX + 2;
}
